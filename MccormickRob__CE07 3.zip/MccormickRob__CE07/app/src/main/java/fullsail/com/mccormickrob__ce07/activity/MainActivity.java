// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07

package fullsail.com.mccormickrob__ce07.activity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import fullsail.com.mccormickrob__ce07.core.CommonUtils;
import fullsail.com.mccormickrob__ce07.core.Constant;
import fullsail.com.mccormickrob__ce07.fragment.NewsFragment;
import fullsail.com.mccormickrob__ce07.model.NewsReader;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import fullsail.com.mccormickrob__ce07.R;

public class MainActivity extends AppCompatActivity {

    private TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = findViewById(R.id.textview);
        load_fragment();
    }

    private void load_fragment(){
        Fragment fragment=new NewsFragment();
        if (CommonUtils.getStringSharedPref(MainActivity.this,Constant.SF_AD_DATA,"").equals("")) {
            String url = "https://www.reddit.com/r/subreddit/hot.json";
            FetchNewsIntentService.startNewsFetch(this,url);
            textview.setVisibility(View.VISIBLE);
        } else {

            String title=getIntent().getStringExtra("title");
            String imgUrl=getIntent().getStringExtra("image");
            String newsUrl=getIntent().getStringExtra("newsUrl");

            Bundle bundle= new Bundle();
            bundle.putString("title",title);
            bundle.putString("image",imgUrl);
            bundle.putString("newsUrl",newsUrl);

            String TAG = "MainActivity";
            Log.e(TAG,"Frag_Title"+title);
            Log.e(TAG,"Frag_ImgUrl"+imgUrl);
            Log.e(TAG,"Frag_NewsUrl"+newsUrl);

            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager!= null)
                manager.cancel(11);

            fragment.setArguments(bundle);
            FragmentManager fragmentManager=getFragmentManager();
            FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fram_news,fragment);fragmentTransaction.commit();
        }
    }


    public static ArrayList<NewsReader> getAdData(Context context) {
        Type listType = new TypeToken<List<NewsReader>>() {}.getType();
        return new Gson().fromJson(CommonUtils.getStringSharedPref(context, Constant.SF_AD_DATA,""), listType);
    }

    public static void setAdData(Context context, List<NewsReader> jsonArray) {
        Gson gson = new Gson();
        String json = gson.toJson(jsonArray);
        CommonUtils.setStringSharedPref(context, Constant.SF_AD_DATA,json);
    }
}