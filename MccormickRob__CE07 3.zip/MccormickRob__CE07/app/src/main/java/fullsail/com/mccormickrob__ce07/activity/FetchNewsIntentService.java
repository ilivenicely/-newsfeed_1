package fullsail.com.mccormickrob__ce07.activity;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import fullsail.com.mccormickrob__ce07.R;
import fullsail.com.mccormickrob__ce07.model.NewsReader;
import fullsail.com.mccormickrob__ce07.receiver.AlarmReceiver;


public class FetchNewsIntentService extends IntentService {

    public FetchNewsIntentService() {
        super("FetchNewsIntentService");
    }

    private final String TAG="FetchNewsIntentService";

    public static void startNewsFetch(Context context, String url) {
        Intent intent = new Intent(context, FetchNewsIntentService.class);
        intent.putExtra("url",url);
        context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("com.java1.fullsail.image_channel",
                    getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE));
            if (notificationManager!= null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, "com.java1.fullsail.image_channel")
                .setContentTitle(getString(R.string.app_name))
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setOngoing(true)
                .setContentText("Fetching Images").build();
        startForeground(1, notification);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            loadUrl(intent.getStringExtra("url"));
        }
    }


    private void loadUrl(String url) {
        Log.e(TAG, "Main_Url-->" + url);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        jsonResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error -->" + error.getMessage());
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void jsonResponse(String response) {
        try {
            JSONObject object = new JSONObject(response);
            JSONArray array = object.getJSONObject("data").getJSONArray("children");
            ArrayList<NewsReader> newsReaderList = new ArrayList<>();
            for (int i = 0; i <array.length(); i++) {
                JSONObject jsonObject = array.getJSONObject(i).getJSONObject("data");

                String title=jsonObject.getString("title");
                Log.e(TAG,"Title -->"+title);
                String imageUrl=jsonObject.getString("thumbnail");
                Log.e(TAG,"ImageUrl -->"+imageUrl);
                String newsUrl=jsonObject.getString("url");
                Log.e(TAG,"NewsUrl -->"+newsUrl);

                if (!imageUrl.equals("self")) {
                    NewsReader newsReader=new NewsReader(imageUrl,title,newsUrl);
                    newsReaderList.add(newsReader);
                }
            }
            MainActivity.setAdData(getApplicationContext(),newsReaderList);
            setAlarm();
            stopForeground(true);
            stopSelf();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "Response Exception --> " + e.getMessage());
        }
    }

    private void setAlarm(){
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        if (alarmManager!= null)
            alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,60*1000,60*1000, pendingIntent);

    }

}
