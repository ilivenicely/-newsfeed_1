// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07


package fullsail.com.mccormickrob__ce07.core;

import android.content.SharedPreferences;

public class Constant {
    static final String SHARED_PREF_NAME = "SHARED_PREFS_NEWS_READER";
    public static SharedPreferences.Editor m_sharedPrefEditor;
    public static SharedPreferences m_sharedPreference;
    public static final String SF_AD_DATA="SF_AD_DATA";
    public static final String SF_INDEX="SF_INDEX";

    public static final String SF_SAVED_DATA = "SF_SAVED_DATA";
}
