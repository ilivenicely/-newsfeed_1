// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07


package fullsail.com.mccormickrob__ce07.model;

import java.io.Serializable;

public class NewsReader implements Serializable {
    private String urlImage;
    private String title;
    private String newsUrl;

    public NewsReader(String urlImage, String title, String newsUrl) {
        this.newsUrl=newsUrl;
        this.urlImage = urlImage;
        this.title = title;
    }

    public String getNewsUrl() {
        return newsUrl;
    }

    public String getUrlImage() {
        return urlImage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
