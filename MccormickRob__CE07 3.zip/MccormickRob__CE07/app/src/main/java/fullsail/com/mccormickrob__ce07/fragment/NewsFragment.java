// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07


package fullsail.com.mccormickrob__ce07.fragment;


import android.annotation.SuppressLint;
import android.app.ListFragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import fullsail.com.mccormickrob__ce07.core.CommonUtils;
import fullsail.com.mccormickrob__ce07.core.Constant;
import fullsail.com.mccormickrob__ce07.model.NewsReader;
import fullsail.com.mccormickrob__ce07.R;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("ValidFragment")
public class NewsFragment extends ListFragment {
    private List<NewsReader> newsReaderList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_news,container,false);
        String title = getArguments().getString("title");
        String imageUrl = getArguments().getString("image");
        String newsUrl = getArguments().getString("newsUrl");
        NewsReader newsReader = null;
        if (title!= null && !title.equals("")) {
            newsReader = new NewsReader(imageUrl, title, newsUrl);
        }
        String json = CommonUtils.getStringSharedPref(getActivity(),Constant.SF_SAVED_DATA,"");
        List<NewsReader> newsList=null;
        Gson gson = new Gson();
        Type type = new TypeToken<List<NewsReader>>(){}.getType();
        if (!json.equals("")) {
            newsList = gson.fromJson(json, type);
        }
        if (newsList== null)
            newsList = new ArrayList<>();

        if (newsReader!= null) {
            newsList.add(newsReader);
            CommonUtils.setStringSharedPref(getActivity(),Constant.SF_SAVED_DATA,gson.toJson(newsList,type));
        }

        newsReaderList = new ArrayList<>(newsList);
        setListAdapter(new NewsReaderAdapter(newsReaderList));

        return view;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(newsReaderList.get(position).getNewsUrl()));
        startActivity(intent);
    }

    @SuppressLint("StaticFieldLeak")
    class generatePictureStyleNotification extends AsyncTask<String, Void, Bitmap> {
        String imageURL;
        ImageView imageView;

        generatePictureStyleNotification(String imageUrl, ImageView imageView) {
            this.imageURL=imageUrl;
            this.imageView=imageView;
        }

        @Override
        protected Bitmap doInBackground(String... strings) {

            InputStream in;
            try {
                URL url = new URL(this.imageURL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                in = connection.getInputStream();
                return BitmapFactory.decodeStream(in);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            imageView.setImageBitmap(bitmap);
        }
    }

    private class NewsReaderAdapter extends BaseAdapter {
        List<NewsReader> newsReaderList;
        private NewsReaderAdapter(List<NewsReader> newsReaderList) {
            this.newsReaderList=newsReaderList;
        }

        @Override
        public int getCount() {
            return newsReaderList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @SuppressLint("InflateParams")
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if(convertView==null){
                LayoutInflater inflater= LayoutInflater.from(getActivity());
                convertView=inflater.inflate(R.layout.row_list_data,null,false);
                viewHolder=new ViewHolder(convertView);
                convertView.setTag(viewHolder);
            }else {
                viewHolder= (ViewHolder) convertView.getTag();
            }
            viewHolder.title.setText(newsReaderList.get(position).getTitle());
            new generatePictureStyleNotification(newsReaderList.get(position).getUrlImage(),viewHolder.image).execute();
            return convertView;
        }

        class ViewHolder{
            TextView title;
            ImageView image;
            ViewHolder(View convertView) {
                title=convertView.findViewById(R.id.tv_title);
                image=convertView.findViewById(R.id.im_image);
            }
        }
    }

}
