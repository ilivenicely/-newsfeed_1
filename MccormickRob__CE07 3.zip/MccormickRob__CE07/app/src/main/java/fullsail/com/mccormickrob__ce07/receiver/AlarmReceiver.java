// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07


package fullsail.com.mccormickrob__ce07.receiver;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import fullsail.com.mccormickrob__ce07.activity.MainActivity;
import fullsail.com.mccormickrob__ce07.core.CommonUtils;
import fullsail.com.mccormickrob__ce07.core.Constant;
import fullsail.com.mccormickrob__ce07.model.NewsReader;
import fullsail.com.mccormickrob__ce07.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class AlarmReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        ArrayList<NewsReader> newsReaderArrayList = MainActivity.getAdData(context);
        if (newsReaderArrayList!= null && !newsReaderArrayList.isEmpty()) {
            int index = CommonUtils.getIntSharedPref(context, Constant.SF_INDEX,0);
                String title = newsReaderArrayList.get(index).getTitle();
                String image= newsReaderArrayList.get(index).getUrlImage();
                String news= newsReaderArrayList.get(index).getNewsUrl();
                new generatePictureStyleNotification(context,title,image,news).execute();
            if (index >= newsReaderArrayList.size()-1) {
                index = 0;
            } else {
                index++;
            }
            CommonUtils.setIntSharedPref(context,Constant.SF_INDEX,index);
        }
    }

    @SuppressLint("StaticFieldLeak")
    class generatePictureStyleNotification extends AsyncTask<String, Void, Bitmap> {

        private Context mContext;
        private String title,imgUrl,newsUrl;

        generatePictureStyleNotification(Context mContext, String title, String imgUrl, String newsUrl) {
            super();
            this.mContext = mContext;
            this.title = title;
            this.imgUrl = imgUrl;
            this.newsUrl=newsUrl;
        }

        @Override
        protected Bitmap doInBackground(String... strings) {

            InputStream in;
            try {
                URL url = new URL(imgUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                in = connection.getInputStream();
                return BitmapFactory.decodeStream(in);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);

            Intent intent = new Intent(mContext, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("title", title);
            intent.putExtra("image", imgUrl);
            intent.putExtra("newsUrl", newsUrl);
            PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 100, intent, PendingIntent.FLAG_ONE_SHOT);

            String channelId = "CE07_news_reader_notification_channel";

            NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification notif = new  NotificationCompat.Builder(mContext,channelId)
                    .setContentIntent(pendingIntent)
                    .setContentTitle(title)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setLargeIcon(result)
                    .setStyle(new NotificationCompat.BigPictureStyle().bigPicture(result))
                    .addAction(R.drawable.ic_launcher_background,"Save",pendingIntent)
                    .build();

            notif.flags |= Notification.FLAG_AUTO_CANCEL;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(channelId,
                        "Channel human readable title",
                        NotificationManager.IMPORTANCE_DEFAULT);
                if (notificationManager!=null)
                    notificationManager.createNotificationChannel(channel);
            }

            if (notificationManager!=null)
                notificationManager.notify(11, notif);

        }
    }
}
