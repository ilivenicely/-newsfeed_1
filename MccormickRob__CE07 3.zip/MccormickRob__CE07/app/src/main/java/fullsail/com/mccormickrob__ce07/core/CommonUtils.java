// Robert McCormick
// JAV2 -  MDV3830-O 01 C201807
// MccormickRob_CE07


package fullsail.com.mccormickrob__ce07.core;

import android.annotation.SuppressLint;
import android.content.Context;

import static fullsail.com.mccormickrob__ce07.core.Constant.SHARED_PREF_NAME;

public class CommonUtils {

//    private static String p_spKey;
//    private static String p_value;
//    private static Context p_context;

//    public static int getIntSharedPref() {
//        return getIntSharedPref(, , );
//    }

    public static int getIntSharedPref(Context p_context, String p_spKey, int p_value) {

        setSharedPreference(p_context);
        return Constant.m_sharedPreference.getInt(p_spKey, p_value);
    }

   /*
    public static int getIntSharedPref(Context p_context, String p_spKey, int p_value) {

        setSharedPreference(p_context);
        return Constant.m_sharedPreference.getInt(p_spKey, p_value);
    } */

    public static void setIntSharedPref(Context p_context, String p_spKey, Integer p_value) {

        setEditor(p_context);
        Constant.m_sharedPrefEditor.putInt(p_spKey, p_value);
        Constant.m_sharedPrefEditor.commit();
    }

    public static void setStringSharedPref(Context p_context, String p_spKey, String p_value) {

        setEditor(p_context);
        Constant.m_sharedPrefEditor.putString(p_spKey, p_value);
        Constant.m_sharedPrefEditor.commit();
    }

    public static String getStringSharedPref(Context p_context, String p_spKey, String p_value) {

        setSharedPreference(p_context);
        return Constant.m_sharedPreference.getString(p_spKey, p_value);
    }

    @SuppressLint("CommitPrefEdits")
    private static void setEditor(Context p_context) {

        setSharedPreference(p_context);
        if (Constant.m_sharedPrefEditor == null)
            Constant.m_sharedPrefEditor = Constant.m_sharedPreference.edit();
    }

    private static void setSharedPreference(Context p_context) {
        if (Constant.m_sharedPreference == null)
            Constant.m_sharedPreference = p_context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
    }
}
